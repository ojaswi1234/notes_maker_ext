const headers = document.querySelectorAll('h1');
const h2s = document.querySelectorAll('h2');
const h3 = document.querySelectorAll('h3');
const h4 = document.querySelectorAll('h4');
/*
headers.forEach(header => {
    header.style.fontFamily = "Tahoma";
});


h2s.forEach(h2 => {
  
    h2.style.fontFamily = "papyrus";
});
h3.forEach(h3 => {
    h3.style.fontFamily = "papyrus";
}
);
h4.forEach(h4 => {
    h4.style.fontFamily = "papyrus";
});

const labels = document.querySelectorAll('label');
labels.forEach(label => {
    label.style.fontFamily = "papyrus";
});
const li = document.querySelectorAll('li');
li.forEach(li => {
    li.style.fontFamily = "papyrus";
});
const a = document.querySelectorAll('a');
a.forEach(a => {
    a.style.fontFamily = "papyrus";
});
const button = document.querySelectorAll('button');
button.forEach(button => {
    button.style.fontFamily = "papyrus";
});
const input = document.querySelectorAll('input');
input.forEach(input => {
    input.style.fontFamily = "papyrus";
});
const textarea = document.querySelectorAll('textarea');
textarea.forEach(textarea => {
    textarea.style.fontFamily = "papyrus";
});
const select = document.querySelectorAll('select');
select.forEach(select => {
    select.style.fontFamily = "papyrus";
});


const para = document.querySelectorAll('p');
para.forEach(p => {
    p.style.fontFamily = "papyrus";
});
*/





/*
const divs = document.querySelectorAll('div');
if (divs.length > 0) {
    divs.forEach(div => {
        div.style.backgroundColor = "black";
        div.style.color = "green"; 
    });
}

const para = document.querySelectorAll('p');
if (para.length > 0) {
    para.forEach(p => {
        p.style.backgroundColor = "black";
        p.style.color = "green"; 
    });
}

const btn = document.querySelectorAll('button');
if (btn.length > 0) {
    btn.forEach(button => {
        button.style.backgroundColor = "black";
        button.style.color = "green"; 
    });
}

if (headers.length > 0) {
    headers.forEach(header => {
        header.style.backgroundColor = "black";
        header.style.color = "green";
    });
}

if (h2s.length > 0) {
    h2s.forEach(h2 => {
        h2.style.backgroundColor = "black";
        h2.style.color = "cyan";
    });
}

if (h3.length > 0) {
    h3.forEach(h3 => {
        h3.style.color = "red";
    });
}

if (h4.length > 0) {
    h4.forEach(h4 => {
        h4.style.backgroundColor = "black";
        h4.style.color = "green";
    });
}

const labels = document.querySelectorAll('label');
if (labels.length > 0) {
    labels.forEach(label => {
        label.style.backgroundColor = "black";
        label.style.color = "yellow";
    });
}

*/